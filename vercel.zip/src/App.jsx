import VideoCallApp from './components/VideoCallApp'

function App() {
  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <VideoCallApp />
    </div>
  )
}

export default App